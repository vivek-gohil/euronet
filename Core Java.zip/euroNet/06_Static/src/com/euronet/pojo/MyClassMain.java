package com.euronet.pojo;

public class MyClassMain {
	public static void main(String[] args) {
		MyClass myClass = new MyClass();
		myClass.display();

		System.out.println("---------------------------------");

		MyClass myClass2 = new MyClass();
		myClass2.display();
	}
}
