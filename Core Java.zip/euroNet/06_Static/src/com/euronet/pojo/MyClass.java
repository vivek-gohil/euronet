package com.euronet.pojo;

public class MyClass {
	private static int num1 = 10;
	private int num2 = 10;

	public void display() {
		System.out.println("Num1 :: " + num1);
		System.out.println("Num2 :: " + num2);
		num1++;
		num2++;
		System.out.println("Num1 :: " + num1);
		System.out.println("Num2 :: " + num2);
	}
	
	
}
