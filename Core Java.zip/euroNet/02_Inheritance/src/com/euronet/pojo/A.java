package com.euronet.pojo;

public class A {

	public A() {
		System.out.println("Hi");
	}

	public A(int x) {
		System.out.println("Hi " + x);
	}

	private int temp;

	public void show() {
		System.out.println("show() of class A");
	}
}
