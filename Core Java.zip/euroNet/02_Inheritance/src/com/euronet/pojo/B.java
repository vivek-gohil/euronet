package com.euronet.pojo;

public class B extends A {

	public B() {
		super();
		System.out.println("Hello");
	}

	public B(int x) {
		super(x);
		System.out.println("Hello " + x);
	}

	public void display() {
		System.out.println("display() of class B");
		A a = new A();
		a.show();
	}

	public void show() {
		super.show();
		System.out.println("show() of class B");
	}
}
