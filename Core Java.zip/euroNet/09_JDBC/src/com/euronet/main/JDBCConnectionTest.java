package com.euronet.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnectionTest {
	public static void main(String[] args) {

		try {
			// 1. Load driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2. Create Connection
			Connection connection = DriverManager.getConnection
					("jdbc:mysql://localhost:3306/euronetdb", "root","Bahubali@01");
			if (connection != null) {
				System.out.println("Connection Success!");
				connection.close();
			} else {
				System.out.println("Connection Failed");
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Connection Failed");
			System.out.println(e.getMessage());
		}
	}
}
