package com.euronet.main;

import java.util.List;
import java.util.Scanner;

import com.euronet.dao.EmployeeDAO;
import com.euronet.pojo.Employee;

public class EmployeeCRUDMainV2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		// EmployeeCRUD crud = new EmployeeCRUD();
		EmployeeDAO crud = new EmployeeDAO();
		int choice;
		int employeeId;
		String name;
		double salary;
		boolean result;
		String continueChoice;
		Employee employee;
		do {
			System.out.println("Menu");
			System.out.println("1. Add Employee");
			System.out.println("2. Update Existing Employee");
			System.out.println("3. Delete Employee");
			System.out.println("4. Get Single Employee");
			System.out.println("5. Get All Employees");
			System.out.println("Enter your choice");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter employeeid");
				employeeId = scanner.nextInt();
				System.out.println("Enter name");
				name = scanner.next();
				System.out.println("Enter salary");
				salary = scanner.nextDouble();
				employee = new Employee(employeeId, name, salary);
				result = crud.addEmployee(employee);
				if (result) {
					System.out.println("Employee added successfully");
				} else {
					System.out.println("Failed to add employee");
				}
				break;
			case 2:
				System.out.println("Enter employeeid");
				employeeId = scanner.nextInt();
				System.out.println("Enter new name");
				name = scanner.next();
				System.out.println("Enter new salary");
				salary = scanner.nextDouble();
				employee = new Employee(employeeId, name, salary);
				result = crud.updateEmployee(employee);
				if (result)
					System.out.println("Employee update successfully");
				else
					System.out.println("Failed to update employee");
				break;
			case 3:
				System.out.println("Enter employeeid");
				employeeId = scanner.nextInt();
				result = crud.deleteEmployee(employeeId);
				if (result)
					System.out.println("Employee deleted successfully");
				else
					System.out.println("Failed to delete employee");
				break;
			case 4:
				System.out.println("Enter employeeid");
				employeeId = scanner.nextInt();
				employee = crud.getEmployee(employeeId);
				if (employee != null)
					System.out.println(employee);
				else
					System.out.println("No employee found!");
				break;
			case 5:
				List<Employee> employeeList = crud.getAllEmployees();
				for (Employee emp : employeeList) {
					System.out.println(emp);
				}
				System.out.println("-------------------------");
				for (Employee e : crud.getAllEmployees()) {
					System.out.println(e);
				}
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();

		} while (continueChoice.equals("yes"));

	}

}
