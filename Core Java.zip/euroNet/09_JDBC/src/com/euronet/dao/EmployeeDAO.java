package com.euronet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import com.euronet.pojo.Employee;

public class EmployeeDAO {

	Connection connection = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	String url = "jdbc:mysql://localhost:3306/euronetdb";
	String user = "root";
	String password = "Bahubali@01";
	String sql = "";
	int count;
	String driver = "com.mysql.cj.jdbc.Driver";
	List<Employee> employeeList = new ArrayList<Employee>();
	Employee employee = null;

	public boolean addEmployee(Employee employee) {
		try {
			// 1. Load driver
			Class.forName(driver);
			// 2. Connection
			connection = DriverManager.getConnection(url, user, password);
			if (connection != null) {
				// 3. Write sql query
				sql = "insert into employee_master values(?,?,?)";

				// 4. Create Employee Object
				// employee = new Employee(106, "Meena", 1000);

				// 5. Execute SQL Query
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setInt(1, employee.getEmployeeId());
				preparedStatement.setString(2, employee.getName());
				preparedStatement.setDouble(3, employee.getSalary());

				count = preparedStatement.executeUpdate();

				if (count > 0) {
					return true;
				} else {
					return false;
				}

			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	public boolean updateEmployee(Employee employee) {
		try {
			// 1. Load driver
			Class.forName(driver);
			// 2. Connection
			connection = DriverManager.getConnection(url, user, password);
			if (connection != null) {
				// 3. Write sql query
				sql = "update employee_master set name=? , salary=? where employee_id=?";

				// 4. Create Employee Object
				// Employee employee = new Employee(101, "Vivek G", 10000);

				// 5. Execute SQL Query
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, employee.getName());
				preparedStatement.setDouble(2, employee.getSalary());
				preparedStatement.setInt(3, employee.getEmployeeId());

				count = preparedStatement.executeUpdate();

				if (count > 0) {
					return true;
				} else {
					return false;
				}

			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	public boolean deleteEmployee(int employeeId) {

		try {
			// 1. Load driver
			Class.forName(driver);
			// 2. Connection
			connection = DriverManager.getConnection(url, user, password);
			if (connection != null) {
				// 3. Write sql query
				sql = "delete from employee_master where employee_id = ?";

				// int employeeId = 101;
				// 5. Execute SQL Query
				preparedStatement = connection.prepareStatement(sql);

				preparedStatement.setInt(1, employeeId);

				count = preparedStatement.executeUpdate();

				if (count > 0) {
					return true;
				} else {
					return false;
				}

			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return false;
	}

	public Employee getEmployee(int employeeId) {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			if (connection != null) {
				sql = "select * from employee_master where employee_id = ?";
				// int employeeId = 102;
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setInt(1, employeeId);

				resultSet = preparedStatement.executeQuery();
				if (resultSet.next()) {
					int empId = resultSet.getInt("employee_id");
					String name = resultSet.getString("name");
					double salary = resultSet.getDouble("salary");

					employee = new Employee(empId, name, salary);
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return employee;
	}

	public List<Employee> getAllEmployees() {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			if (connection != null) {
				sql = "select * from employee_master";
				preparedStatement = connection.prepareStatement(sql);
				resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					int employeeId = resultSet.getInt("employee_id");
					String name = resultSet.getString("name");
					double salary = resultSet.getDouble("salary");

					employee = new Employee(employeeId, name, salary);
					employeeList.add(employee);
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return employeeList;
	}
}
