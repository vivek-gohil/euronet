package com.euronet.threads;

public class ThreadOne implements Runnable {
	@Override
	public void run() {
		System.out.println("ThreadOne started");
		for (int i = 0; i < 10; i++) {
			System.out.println("ThreadOne :: " + i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("ThreadOne finished");
	}
}
