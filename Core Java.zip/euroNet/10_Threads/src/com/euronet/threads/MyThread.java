package com.euronet.threads;

public class MyThread implements Runnable {
	public void run() {
		System.out.println("We are in MyThread");
		for (int i = 0; i < 1000; i++) {
			System.out.println("MyThread " + i);
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("MyThread Ends");
	}
}
