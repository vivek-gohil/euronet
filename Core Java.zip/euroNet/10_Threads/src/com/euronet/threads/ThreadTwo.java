package com.euronet.threads;

public class ThreadTwo implements Runnable {
	@Override
	public void run() {
		System.out.println("ThreadTwo started");
		for (int i = 0; i < 10; i++) {
			System.out.println("ThreadTwo :: " + i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("ThreadTwo finished");
	}
}
