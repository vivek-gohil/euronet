package com.euronet.main;

import com.euronet.threads.ThreadOne;
import com.euronet.threads.ThreadTwo;

public class MainThreads {
	public static void main(String[] args) {
		System.out.println("Main start");

		Runnable runnableOne = new ThreadOne();
		Runnable runnableTwo = new ThreadTwo();

		Thread threadOne = new Thread(runnableOne);
		Thread threadTwo = new Thread(runnableTwo);

		threadOne.start();

		try {
			threadOne.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		threadTwo.start();

		try {
			threadTwo.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Main end");
	}
}
