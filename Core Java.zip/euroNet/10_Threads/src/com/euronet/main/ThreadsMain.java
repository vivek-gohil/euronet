package com.euronet.main;

public class ThreadsMain {
	public static void main(String[] args) {
		Thread thread;
		thread = Thread.currentThread();
		System.out.println(thread);
		System.out.println("");
		thread.setName("MyMainThread");
		System.out.println(thread);
		System.out.println("");
		thread.setPriority(10);
		System.out.println(thread);
	}
}
