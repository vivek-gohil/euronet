package com.euronet.main;

import com.euronet.threads.MyThread;

public class MyThreadMain {
	public static void main(String[] args) {
		System.out.println("Main start");

		Runnable runnable = new MyThread();

		// MyThread myThread = new MyThread();
		Thread thread = new Thread(runnable);
		thread.start();

		for (int i = 0; i < 1000; i++) {
			System.out.println("main " + i);
		}
		System.out.println();
		System.out.println("Main end");

	}
}
