package com.euronet.thread;

import com.euronet.pojo.Message;

public class MessageThread implements Runnable {

	private String message;
	private Message myMessage;

	public MessageThread(String message, Message myMessage) {
		super();
		this.message = message;
		this.myMessage = myMessage;
	}

	@Override
	public void run() {
		myMessage.printMessage(message);
	}
}
