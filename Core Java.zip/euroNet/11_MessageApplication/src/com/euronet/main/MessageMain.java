package com.euronet.main;

import com.euronet.pojo.Message;
import com.euronet.thread.MessageThread;

public class MessageMain {
	public static void main(String[] args) {

		Message message = new Message();

		Runnable messageThreadOne = new MessageThread("Hi", message);
		Thread messageOne = new Thread(messageThreadOne);
		messageOne.start();

		Runnable messageThreadTwo = new MessageThread("Hello", message);
		Thread messageTwo = new Thread(messageThreadTwo);
		messageTwo.start();

		Runnable mesageThreadThree = new MessageThread("How are you", message);
		Thread messageThree = new Thread(mesageThreadThree);
		messageThree.start();

	}
}
