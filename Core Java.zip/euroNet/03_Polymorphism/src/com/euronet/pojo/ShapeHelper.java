package com.euronet.pojo;

public class ShapeHelper {
	public Shapes getShape(int choice) {
		switch (choice) {
		case 1:
			Circle circle = new Circle();
			return circle;
		case 2:
			Triangle triangle = new Triangle();
			return triangle;
		case 3:
			Line line = new Line();
			return line;
		}
		return null;
	}
}
