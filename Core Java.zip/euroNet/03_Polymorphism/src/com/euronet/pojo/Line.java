package com.euronet.pojo;
//Spacialization
public class Line extends Shapes {
	@Override
	public void draw() {
		System.out.println("Drawing Line");
	}
}
