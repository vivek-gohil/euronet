package com.euronet.pojo;
//Spacialization
public class Triangle extends Shapes {

	public void draw() {
		System.out.println("Drwaing Triangle");
	}
}
