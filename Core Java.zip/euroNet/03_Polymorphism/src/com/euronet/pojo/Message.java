package com.euronet.pojo;

//Generalization
public abstract class Message {


	public Message() {
		// TODO Auto-generated constructor stub
	}

//	public void sendMessage(String msg) {
//		System.out.println("Sending Message :: " + msg);
//	}

	public abstract void sendMessage(String msg);

}
