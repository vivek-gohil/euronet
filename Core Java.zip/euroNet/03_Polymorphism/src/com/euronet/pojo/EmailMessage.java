package com.euronet.pojo;

public class EmailMessage extends Message {
	@Override
	public void sendMessage(String msg) {
		System.out.println("Sending EmailMessage :: " + msg);
	}
}
