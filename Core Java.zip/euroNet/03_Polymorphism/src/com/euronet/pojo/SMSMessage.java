package com.euronet.pojo;

public class SMSMessage extends Message {
	@Override
	public void sendMessage(String msg) {
		System.out.println("Sending SMS Message :: " + msg);
	}
}
