package com.euronet.pojo;
//Spacialization
public class Circle extends Shapes {
	@Override
	public void draw() {
		System.out.println("Drawing Circle");
	}
}
