package com.euronet.pojo;

public class WhatsappMessage extends Message {
	@Override
	public void sendMessage(String msg) {
		System.out.println("Sending Whatsapp Message :: " + msg);
	}

	public void show() {
		System.out.println("We are in show()");
	}
}
