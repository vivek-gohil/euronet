package com.euronet.pojo;
//Generalization
public class Shapes {
	public void draw() {
		System.out.println("Drawing Shapes");
	}
}
