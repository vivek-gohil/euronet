package com.euronet.pojo;

public class MessageHelper {
	public Message getMessage(int choice) {
		switch (choice) {
		case 1:
			SMSMessage sms = new SMSMessage();
			return sms;
		case 2:
			EmailMessage email = new EmailMessage();
			return email;
		case 3:
			WhatsappMessage whatsapp = new WhatsappMessage();
			return whatsapp;
		}
		return null;
	}
}
