package com.euronet.main;

import java.util.Scanner;

import com.euronet.pojo.ShapeHelper;
import com.euronet.pojo.Shapes;

public class ShapesMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ShapeHelper shapeHelper = new ShapeHelper();
		Shapes shapes = null;

		int choice;

		System.out.println("1. Circle");
		System.out.println("2. Triangle");
		System.out.println("3. Line");
		System.out.println("Enter your choice");
		choice = scanner.nextInt();
		System.out.println("Select option is " + choice);

		// Polymorphism
		shapes = shapeHelper.getShape(choice);
		shapes.draw();
		
		

	}
}
