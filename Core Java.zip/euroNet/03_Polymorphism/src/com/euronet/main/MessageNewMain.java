package com.euronet.main;

import com.euronet.pojo.Message;
import com.euronet.pojo.WhatsappMessage;

public class MessageNewMain {
	public static void main(String[] args) {
		Message message = new WhatsappMessage();
		
	}
}
