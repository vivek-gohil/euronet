package com.euronet.main;

import java.util.Scanner;

import com.euronet.pojo.Message;
import com.euronet.pojo.MessageHelper;

public class MessageMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		MessageHelper messageHelper = new MessageHelper();
		Message message = null;
		int choice;
		String msg;

		System.out.println("Menu");
		System.out.println("1. SMS Message");
		System.out.println("2. Email Message");
		System.out.println("3. Whatsapp Message");
		System.out.println("Enter your choice");
		choice = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter message to be sent");
		msg = scanner.nextLine();
		message = messageHelper.getMessage(choice);

		message.sendMessage(msg);
		

	}
}
