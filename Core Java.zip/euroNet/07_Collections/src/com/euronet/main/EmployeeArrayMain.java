package com.euronet.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.euronet.pojo.Employee;

public class EmployeeArrayMain {
	public static void main(String[] args) {
		Employee employee1 = new Employee(101, "Vivek Gohil", 1000);
		Employee employee2 = new Employee(102, "Bill Gates", 100000);
		Employee employee3 = new Employee(101, "Elon Musk", 1000000);

		// int[] num = new int[5];
		Employee[] employees = new Employee[5];
		employees[0] = employee1;
		employees[1] = employee2;
		employees[2] = employee3;

		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList = Arrays.asList(employees);

		System.out.println(employeeList);
		for (Employee employee : employeeList) {
			System.out.println(employee);
		}
	}
}
