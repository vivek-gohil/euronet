package com.euronet.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Consumer;

public class CollectionsMain {
	public static void main(String[] args) {
		int size;
		boolean result;

		System.out.println("Collections Example");
		System.out.println("1.ArrayList");
		List<String> nameList = new ArrayList<String>();
		size = nameList.size();
		System.out.println("Size of ArrayList :: " + size);
		// nameList.add(null);
		nameList.add("Seema");
		nameList.add("Ravi");
		nameList.add("Reema");
		// nameList.add(null);
		nameList.add("Seema");
		nameList.add("Vivek");
		nameList.add("Reema");
		size = nameList.size();
		System.out.println("Size of ArrayList :: " + size);
		System.out.println("Remove element");
		result = nameList.remove("Vivek");
		System.out.println("Result :: " + result);
		System.out.println(nameList);
		
		System.out.println("Using for each loop");
		for (String name : nameList) {
			System.out.println(name);
		}
		
		
		
		System.out.println("Printing all accept Reema");
		for (String name : nameList) {
			if (!name.equals("Reema"))
				System.out.println(name);
		}
		System.out.println("Printing using foreach method : Regurlar Expression");
		nameList.forEach(name -> System.out.println(name));

		System.out.println("Seache the object");
		System.out.println("Searching Reema");
		result = nameList.contains("Reema");
		System.out.println("Result is :: " + result);
		System.out.println("");
		System.out.println("2.HashSet");
		Set<Integer> numberSet = new HashSet<Integer>();
		size = numberSet.size();
		System.out.println("Size :: " + size);
		numberSet.add(20);
		numberSet.add(11);
		numberSet.add(65);
		numberSet.add(20);
		numberSet.add(11);
		// numberSet.add(null);
		// numberSet.add(null);
		size = numberSet.size();
		System.out.println("Size :: " + size);
		System.out.println(numberSet);
		System.out.println("Print Using For");
		for (Integer num : numberSet) {
			System.out.println(num);
		}

		System.out.println("Searching 65");
		result = numberSet.contains(65);
		System.out.println("Result is :: " + result);
		System.out.println("3.TreeSet");
		SortedSet<String> nameSortedSet = new TreeSet<String>();
		size = nameSortedSet.size();
		System.out.println("Size :: " + size);
		nameSortedSet.add("d");
		nameSortedSet.add("a");
		nameSortedSet.add("b");
		nameSortedSet.add("a");
		nameSortedSet.add("cc");
		nameSortedSet.add("B");
		nameSortedSet.add("A");
		nameSortedSet.add("B");
		// nameSortedSet.add(null);
		size = nameSortedSet.size();
		System.out.println("Size :: " + size);
		System.out.println(nameSortedSet);
		System.out.println("Printing Using for loop");
		for (String name : nameSortedSet) {
			System.out.println(name);
		}
		System.out.println("4.HashMap");
		Map<Integer, String> employeeMap = new HashMap<Integer, String>();
		employeeMap.put(1, "Vivek");
		employeeMap.put(102, "Reema");
		employeeMap.put(103, "Aniket");
		employeeMap.put(1, "Seema");
		employeeMap.put(null, null);
		employeeMap.put(null, "Test");
		System.out.println(employeeMap);

		System.out.println("5. TreeMap");
		SortedMap<Integer, String> nameMap = new TreeMap<Integer, String>();
		nameMap.put(1, "Vivek");
		nameMap.put(102, "Reema");
		nameMap.put(103, "Aniket");
		nameMap.put(2, "Seema");
//		nameMap.put(null, null);
//		nameMap.put(null, "Test");
		System.out.println(nameMap);
		String name = nameMap.get(3);
		System.out.println("Value :: " + name);

		Set<Integer> allKeys = nameMap.keySet();
		System.out.println("All keys");
		System.out.println(allKeys);
		for (Integer num : allKeys) {
			System.out.println("Key :: " + num);
			System.out.println("Value :: " + nameMap.get(num));
			System.out.println("-------------------------------");
		}
	}
}
