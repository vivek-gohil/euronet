package com.euronet.dao;

import java.util.HashSet;
import java.util.Set;

import com.euronet.pojo.Employee;

public class EmployeeCRUD {
	private Set<Employee> employeeSet = new HashSet<Employee>();
	private boolean result;

	public boolean addEmployee(Employee employee) {
		result = employeeSet.add(employee);
		return result;
	}

	public boolean updateEmployee(Employee employee) {
		for (Employee emp : employeeSet) {
			if (emp.getEmployeeId() == employee.getEmployeeId()) {
				emp.setName(employee.getName());
				emp.setSalary(employee.getSalary());
				return true;
			}
		}
		return false;
	}

	public boolean deleteEmployee(int employeeId) {
		for (Employee employee : employeeSet) {
			if (employee.getEmployeeId() == employeeId) {
				employeeSet.remove(employee);
				return true;
			}
		}
		return false;
	}

	public Employee getEmployee(int employeeId) {
		for (Employee employee : employeeSet) {
			if (employee.getEmployeeId() == employeeId) {
				return employee;
			}
		}
		return null;
	}

	public Set<Employee> getAllEmployees() {
		return employeeSet;
	}

}
