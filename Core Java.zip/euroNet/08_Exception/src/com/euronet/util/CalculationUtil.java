package com.euronet.util;

import java.util.InputMismatchException;
import java.util.Scanner;

public class CalculationUtil {
	private double num;
	private Scanner scanner = new Scanner(System.in);

	
	public void accept() {
		try {
			Class.forName("");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void calculate() {
		System.out.println("In Finding number!");

	}

	public void display() {
		System.out.println("Your number :: " + num);

	}
}
