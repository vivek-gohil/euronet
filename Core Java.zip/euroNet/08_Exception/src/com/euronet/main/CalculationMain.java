package com.euronet.main;

import com.euronet.util.CalculationUtil;

public class CalculationMain {
	public static void main(String[] args) {
		CalculationUtil calculationUtil = new CalculationUtil();
		calculationUtil.accept();
		calculationUtil.calculate();
		calculationUtil.display();
	}
}
