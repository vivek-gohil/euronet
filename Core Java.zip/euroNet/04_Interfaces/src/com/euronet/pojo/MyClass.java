package com.euronet.pojo;

public class MyClass implements MyInterface {

	@Override
	public void show() {
		System.out.println("Hello");
	}

}
