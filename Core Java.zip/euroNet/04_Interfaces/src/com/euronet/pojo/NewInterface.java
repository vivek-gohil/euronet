package com.euronet.pojo;

public interface NewInterface {
	void display();
}
