package com.euronet.pojo;

public interface MyInterface {
	void show();

	// public abstract void show();
	
	default void print() {
		System.out.println("Default print method");
	}
}
