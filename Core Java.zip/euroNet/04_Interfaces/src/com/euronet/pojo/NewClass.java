package com.euronet.pojo;

public class NewClass {
	public void show() {
		System.out.println("Hi");
	}
}
