package com.euronet.main;

import com.euronet.pojo.MyClass;
import com.euronet.pojo.MyInterface;
import com.euronet.pojo.NewClass;

public class MyMain {
	public static void main(String[] args) {
		System.out.println("Using simple function call");
		MyClass myClass = new MyClass();
		myClass.show();

		System.out.println("----------------------------");
		System.out.println("Using Polymorphism");

		MyInterface myInterface = new MyClass();
		myInterface.show();

		myInterface = new NewClass();
		
		
		
		
		

	}
}
