package com.euronet.pojo;

public class Account {
	private int amount = 10000;

	public synchronized int withdraw(int amount) {
		System.out.println("In withdraw");
		if (this.amount < amount) {
			System.out.println("Less balance... ");
			System.out.println("Waiting for deposit");
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.amount = this.amount - amount;
		System.out.println("Withdraw completed");
		return this.amount;
	}

	public synchronized int deposit(int amount) {
		System.out.println("In deposit");
		this.amount = this.amount + amount;
		System.out.println("Deposit completed");
		notify();
		return this.amount;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}
