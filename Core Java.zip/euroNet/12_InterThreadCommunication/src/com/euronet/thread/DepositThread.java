package com.euronet.thread;

import com.euronet.pojo.Account;

public class DepositThread implements Runnable {

	private Account account;
	private int amount;

	public DepositThread(Account account, int amount) {
		super();
		this.account = account;
		this.amount = amount;
	}

	@Override
	public void run() {
		int balance = account.deposit(amount);
		System.out.println("Balance after deposit :: " + balance);
	}
}
