package com.euronet.thread;

import com.euronet.pojo.Account;

public class WithdrawThread implements Runnable {
	private Account account;
	private int amount;

	public WithdrawThread(Account account, int amount) {
		super();
		this.account = account;
		this.amount = amount;
	}

	@Override
	public void run() {
		int balance = account.withdraw(amount);
		System.out.println("Balance after withdraw :: " + balance);
	}
}
