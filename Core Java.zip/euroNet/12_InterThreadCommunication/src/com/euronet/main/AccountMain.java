package com.euronet.main;

import com.euronet.pojo.Account;
import com.euronet.thread.DepositThread;
import com.euronet.thread.WithdrawThread;

public class AccountMain {
	public static void main(String[] args) {
		Account account = new Account();
		System.out.println("Balance :: " + account.getAmount());
		System.out.println("Main thread is calling withdraw");

		Runnable withdrawThread = new WithdrawThread(account, 5000);
		Thread withdraw = new Thread(withdrawThread);
		withdraw.start();

		Runnable depositThread = new DepositThread(account, 10000);
		Thread deposit = new Thread(depositThread);
		deposit.start();

		try {
			deposit.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Balance after withdraw :: " + account.getAmount());

	}
}
