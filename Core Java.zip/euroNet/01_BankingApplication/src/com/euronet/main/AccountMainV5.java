package com.euronet.main;

import com.euronet.pojo.Current;

public class AccountMainV5 {

	public static void main(String[] args) {
		Current current = new Current(101, "Vivek Gohil", 10000, 50000);

		System.out.println(current);
		System.out.println("1.withdraw :: 5000");
		current.withdraw(5000);
		System.out.println("Balance :: " + current.getBalance());
		System.out.println("OverdraftBalance :: " + current.getOverdraftBalance());
		System.out.println("---------------------------------------------------");
		System.out.println("2.withdraw :: 15000");
		current.withdraw(15000);
		System.out.println("Balance :: " + current.getBalance());
		System.out.println("OverdraftBalance :: " + current.getOverdraftBalance());
		System.out.println("---------------------------------------------------");
		System.out.println("3.deposit :: 5000");
		current.deposit(5000);
		System.out.println("Balance :: " + current.getBalance());
		System.out.println("OverdraftBalance :: " + current.getOverdraftBalance());
		System.out.println("---------------------------------------------------");
		System.out.println("4.deposit :: 20000");
		current.deposit(20000);
		System.out.println("Balance :: " + current.getBalance());
		System.out.println("OverdraftBalance :: " + current.getOverdraftBalance());
		System.out.println("---------------------------------------------------");

	}

}
