package com.euronet.main;

import com.euronet.pojo.Account;

public class AccountMain {
	public static void main(String[] args) {

//		Account account = new Account();
//
//		account.setAccountNumber(101);
//		account.setName("Vivek Gohil");
//		account.setBalance(1000);

//		System.out.println("Account Number :: " + account.getAccountNumber());
//		System.out.println("Name  :: " + account.getName());
//		System.out.println("Balance :: " + account.getBalance());

		Account account = new Account(101, "Vivek Gohil", 1000);

		System.out.println(account);
		System.out.println(account.hashCode());

		System.out.println("-".repeat(50));

//		Account account2 = new Account();
//
//		account2.setAccountNumber(102);
//		account2.setName("Reema Rai");
//		account2.setBalance(2000);

//		System.out.println("Account Number :: " + account2.getAccountNumber());
//		System.out.println("Name  :: " + account2.getName());
//		System.out.println("Balance :: " + account2.getBalance());

		Account account2 = new Account(102, "Reema Rai", 2000);
		System.out.println(account2);
		System.out.println(account2.hashCode());

	}
}
