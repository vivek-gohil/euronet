package com.euronet.main;

import java.util.Scanner;

import com.euronet.pojo.Account;
import com.euronet.pojo.Savings;

public class AccountMainV4 {
	public static void main(String[] args) {
//		Savings savings = new Savings(101, "Vivek Gohil", 1000, false);
//
//		System.out.println(savings);

		Scanner scanner = new Scanner(System.in);

		int accountNumber;
		String name;
		double balance;
		int choice;
		double amount;
		boolean result;
		String continueChoice;
		boolean isSalary;
		String accountChoice;

		System.out.println("Enter account number");
		accountNumber = scanner.nextInt();

		System.out.println("Enter name");
		name = scanner.next();

		System.out.println("Enter balance");
		balance = scanner.nextDouble();

		System.out.println("Do you want to open salary account");
		accountChoice = scanner.next();

		System.out.println("Your account opened successfully!");

		isSalary = accountChoice.equals("yes") ? true : false;

		Savings savings = new Savings(accountNumber, name, balance, isSalary);

		System.out.println(savings);

		do {
			System.out.println("1. Withdraw");
			System.out.println("2. Deposit");
			System.out.println("3. Balance");
			System.out.println("Enter your choice");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter amount to withdraw");
				amount = scanner.nextDouble();

				result = savings.withdraw(amount);
				if (result == true) {
					System.out.println("Transaction Success!");
				} else {
					System.out.println("Transaction Failed!");
				}
				break;
			case 2:
				System.out.println("Enter amount to deposit");
				amount = scanner.nextDouble();
				result = savings.deposit(amount);
				if (result == true) {
					System.out.println("Transaction Success");
				} else {
					System.out.println("Transaction failed");
				}
				break;
			case 3:
				System.out.println("Balance :: " + savings.getBalance());
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue??");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));

	}
}
