package com.euronet.main;

import com.euronet.pojo.Account;

public class AccountMainV2 {

	public static void main(String[] args) {

		System.out.println("Main Start");
		Account account;
		account = new Account(101, "Test", 1000);

		System.out.println("-----------------------");

		double balance = new Account(101, "Test", 1000).getBalance();
		System.out.println("Balance : " + balance);

		System.out.println("Main End");

	}

}
