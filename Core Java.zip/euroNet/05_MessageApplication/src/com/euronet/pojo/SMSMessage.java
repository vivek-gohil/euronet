package com.euronet.pojo;

public class SMSMessage extends Message {
	public void sendMessage(String message, String mobileNumber) {
		System.out.println("Sending SMS To : " + mobileNumber);
		System.out.println("SMS Message :: " + message);
	}
}
