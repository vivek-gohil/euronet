package com.euronet.pojo;

public abstract class Message {
	public abstract void sendMessage(String message, String mobileNumber);
}
