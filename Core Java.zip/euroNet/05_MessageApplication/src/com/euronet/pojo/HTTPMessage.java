package com.euronet.pojo;

public class HTTPMessage extends Message implements EncrepDecrpFeature {
	@Override
	public void sendMessage(String message, String ipAddress) {
		System.out.println("Sending HTTPMessage :: " + message);
		System.out.println("On IP :: " + ipAddress);
	}

	@Override
	public void doDecrept() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doEncrept() {
		// TODO Auto-generated method stub

	}
}
