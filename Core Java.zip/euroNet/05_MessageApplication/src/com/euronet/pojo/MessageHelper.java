package com.euronet.pojo;

public class MessageHelper {
	public Message getMessage(int choice) {

		Message message = null;
		switch (choice) {
		case 1:
			message = new SMSMessage();
			break;
		case 2:
			message = new EmailMessage();
			break;
		case 3:
			message = new HTTPMessage();
			break;
		}
		return message;
	}
}
