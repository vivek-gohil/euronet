package com.euronet.pojo;

public class EmailMessage extends Message {

	public void sendMessage(String message, String emaiId) {
		System.out.println("Sending Email To : " + emaiId);
		System.out.println("Email Message :: " + message);
	}
}
