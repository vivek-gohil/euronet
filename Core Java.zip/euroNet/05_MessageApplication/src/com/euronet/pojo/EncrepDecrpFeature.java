package com.euronet.pojo;

public interface EncrepDecrpFeature {
	public abstract void doEncrept();

	public abstract void doDecrept();
}
