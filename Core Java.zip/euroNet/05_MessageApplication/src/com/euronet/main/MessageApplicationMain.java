package com.euronet.main;

import java.util.Scanner;

import com.euronet.pojo.Message;
import com.euronet.pojo.MessageHelper;
import com.euronet.pojo.SMSMessage;

public class MessageApplicationMain {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		MessageHelper messageHelper = new MessageHelper();
		Message message = null;
		String msg, mobileNumber, email, ipAddress;
		int choice;

		System.out.println("1. SMS");
		System.out.println("2. Email");
		System.out.println("3. HTTPMessage");
		System.out.println("Enter your choice");
		choice = scanner.nextInt();
		scanner.nextLine();
		message = messageHelper.getMessage(choice);
		switch (choice) {
		case 1:
			System.out.println("Enter Message");
			msg = scanner.nextLine();
			System.out.println("Enter Mobile Number");
			mobileNumber = scanner.next();
			message.sendMessage(msg, mobileNumber);
			break;
		case 2:
			System.out.println("Enter Message");
			msg = scanner.nextLine();
			System.out.println("Enter Email");
			email = scanner.next();
			message.sendMessage(msg, email);
			break;
		case 3:
			System.out.println("Enter Message");
			msg = scanner.nextLine();
			System.out.println("Enter IP");
			ipAddress = scanner.next();
			message.sendMessage(msg, ipAddress);
			break;
		default:
			System.out.println("Invalid Choice");
			System.exit(0);
			break;
		}

	}
}
