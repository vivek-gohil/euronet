package com.euronet.pojo;

public class Margherita extends Pizza {

	public Margherita() {
		setDescription("Margherita Pizza");
	}

	@Override
	public int getCost() {
		return 100;
	}
}
