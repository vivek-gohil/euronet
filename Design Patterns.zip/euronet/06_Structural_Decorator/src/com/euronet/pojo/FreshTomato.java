package com.euronet.pojo;

public class FreshTomato extends ToppingDecorator {

	private Pizza pizza;

	public FreshTomato(Pizza pizza) {
		this.pizza = pizza;
	}

	@Override
	public String getDescription() {
		return pizza.getDescription() + " , Fresh Tomato Toppings ";
	}

	@Override
	public int getCost() {
		return pizza.getCost() + 40;
	}

}
