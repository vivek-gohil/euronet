package com.euronet.pojo;

public abstract class Pizza {
	
	private String description = "Simple plain pizza base";

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public abstract int getCost();

}
