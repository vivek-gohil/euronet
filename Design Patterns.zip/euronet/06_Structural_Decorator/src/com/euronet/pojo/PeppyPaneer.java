package com.euronet.pojo;

public class PeppyPaneer extends Pizza {

	public PeppyPaneer() {
		setDescription("Peppy Paneer Pizza");
	}

	public int getCost() {
		return 100;
	}
}
