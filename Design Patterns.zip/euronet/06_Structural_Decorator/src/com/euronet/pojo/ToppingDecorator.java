package com.euronet.pojo;

public abstract class ToppingDecorator extends Pizza {
	public abstract String getDescription();
}
