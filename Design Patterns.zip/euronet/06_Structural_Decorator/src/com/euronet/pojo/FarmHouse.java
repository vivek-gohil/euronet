package com.euronet.pojo;

public class FarmHouse extends Pizza {
	
	public FarmHouse() {
		setDescription("Farm House Pizza");
	}

	@Override
	public int getCost() {
		return 200;
	}
}
