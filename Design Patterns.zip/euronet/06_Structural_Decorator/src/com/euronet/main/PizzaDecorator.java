package com.euronet.main;

import com.euronet.pojo.Barbeque;
import com.euronet.pojo.FarmHouse;
import com.euronet.pojo.FreshTomato;
import com.euronet.pojo.Paneer;
import com.euronet.pojo.Pizza;

public class PizzaDecorator {
	public static void main(String[] args) {
		Pizza pizza = new FarmHouse();

		Pizza pizzaWithFreshTomato = new FreshTomato(pizza);

		Pizza pizzaWithTomatoAndBbq = new Barbeque(pizzaWithFreshTomato);

		Pizza pizzaWithTomatoAndBbqAndPaneer = new Paneer(pizzaWithTomatoAndBbq);

		System.out.println(pizzaWithTomatoAndBbqAndPaneer.getDescription());
		System.out.println("Cost :: " + pizzaWithTomatoAndBbqAndPaneer.getCost());

	}
}
