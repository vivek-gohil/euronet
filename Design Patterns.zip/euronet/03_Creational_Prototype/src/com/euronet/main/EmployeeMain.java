package com.euronet.main;

import com.euronet.pojo.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		Employee employee1 = new Employee(101, "Vivek Gohil", 1000);
		System.out.println(employee1);

		// Employee employee2 = new Employee();
		Employee employee2 = null;
		try {
			employee2 = (Employee) employee1.clone();
			System.out.println(employee2);
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		employee2.setName("Reema");
		System.out.println(employee2);

	}
}
