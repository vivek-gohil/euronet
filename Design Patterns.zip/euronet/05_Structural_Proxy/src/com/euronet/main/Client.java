package com.euronet.main;

import com.euronet.pojo.Internet;
import com.euronet.pojo.ProxyInternet;

public class Client {
	public static void main(String[] args) {
		Internet internet = new ProxyInternet();
		internet.connectTo("oracle.com");
	}
}
