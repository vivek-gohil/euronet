package com.euronet.pojo;

public interface Internet {
	public void connectTo(String url);
}
