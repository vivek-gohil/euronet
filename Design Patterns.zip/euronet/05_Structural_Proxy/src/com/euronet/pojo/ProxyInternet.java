package com.euronet.pojo;

import java.util.ArrayList;
import java.util.List;

public class ProxyInternet implements Internet {

	private Internet internet = new RealInternet();
	private static List<String> restrictedSites;

	public ProxyInternet() {
		restrictedSites = new ArrayList<String>();
		restrictedSites.add("jumboproxy.com");
		restrictedSites.add("facebook.com");
		restrictedSites.add("instagram.com");
		restrictedSites.add("adult-site.com");
		restrictedSites.add("bad-site.com");
	}

	@Override
	public void connectTo(String url) {
		if (restrictedSites.contains(url)) {
			System.out.println("Company restricted this site view!");
		} else {
			internet.connectTo(url);
		}
	}
}
