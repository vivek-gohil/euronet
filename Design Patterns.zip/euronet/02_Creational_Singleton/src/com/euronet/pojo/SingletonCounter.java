package com.euronet.pojo;

public class SingletonCounter {
	private int count = 0;
	private static final SingletonCounter counter = new SingletonCounter();

	private SingletonCounter() {
		// TODO Auto-generated constructor stub
	}

	public static synchronized SingletonCounter getInstance() {
		return counter;
	}

	public int getNextValue() {
		
		new SingletonCounter();
		
		return ++count;
	}
}
