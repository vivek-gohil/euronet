package com.euronet.pojo;

public class Counter {
	private int counter = 0;

	public int getNextValue() {
		return ++counter;
	}
}
