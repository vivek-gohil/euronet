package com.euronet.main;

import com.euronet.pojo.SingletonCounter;

public class SingletonCounterMain {
	public static void main(String[] args) {
		SingletonCounter counter1 = SingletonCounter.getInstance();
		System.out.println(counter1.hashCode());
		System.out.println("Value is :: " + counter1.getNextValue());

		SingletonCounter counter2 = SingletonCounter.getInstance();
		System.out.println(counter2.hashCode());
		System.out.println("Value is :: " + counter2.getNextValue());

		// SingletonCounter counter3 = new SingletonCounter();
		SingletonCounter counter3 = SingletonCounter.getInstance();
		System.out.println(counter3.hashCode());
		System.out.println("Value is :: " + counter3.getNextValue());
	}
}
