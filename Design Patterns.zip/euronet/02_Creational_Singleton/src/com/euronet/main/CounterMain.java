package com.euronet.main;

import com.euronet.pojo.Counter;

public class CounterMain {
	public static void main(String[] args) {

		Counter counter = new Counter();
		int value = counter.getNextValue();

		System.out.println("Value is :: " + value);

		Counter counter2 = new Counter();
		value = counter2.getNextValue();

		System.out.println("Value is :: " + value);

	}
}
