package com.euronet.pojo;

public interface Observer {
	public void update(Message message);
}
