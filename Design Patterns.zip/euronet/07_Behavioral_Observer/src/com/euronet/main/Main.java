package com.euronet.main;

import com.euronet.pojo.Message;
import com.euronet.pojo.MessagePublisher;
import com.euronet.pojo.MessageSubscriberOne;
import com.euronet.pojo.MessageSubscriberThree;
import com.euronet.pojo.MessageSubscriberTwo;

public class Main {
	public static void main(String[] args) {
		// Create object of subscriber class
		MessageSubscriberOne subscriberOne = new MessageSubscriberOne();
		MessageSubscriberTwo subscriberTwo = new MessageSubscriberTwo();
		MessageSubscriberThree subscriberThree = new MessageSubscriberThree();

		MessagePublisher publisher = new MessagePublisher();

		publisher.attach(subscriberOne);
		publisher.attach(subscriberTwo);
		publisher.attach(subscriberThree);

		Message message = new Message("Hello to all subscribers");
		
		publisher.notifyUpdate(message);
		
		

	}
}
