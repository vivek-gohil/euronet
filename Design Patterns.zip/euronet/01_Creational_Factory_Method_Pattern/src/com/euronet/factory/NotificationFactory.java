package com.euronet.factory;

import com.euronet.pojo.EmailNotification;
import com.euronet.pojo.Notification;
import com.euronet.pojo.PushNotification;
import com.euronet.pojo.SMSNotification;

public class NotificationFactory {

	public Notification createNotification(String type) {
		if (type.equals("email")) {
			return new EmailNotification();
		}

		if (type.equals("sms")) {
			return new SMSNotification();
		}

		if (type.equals("push")) {
			return new PushNotification();
		}

		return null;

	}
}
