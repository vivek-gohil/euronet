package com.euronet.main;

import java.util.Scanner;

import com.euronet.factory.NotificationFactory;
import com.euronet.pojo.Notification;

public class NotificationService {
	public static void main(String[] args) {
		boolean flag = true;
		String notificationType;
		Scanner scanner = new Scanner(System.in);
		Notification notification = null;
		NotificationFactory factory = new NotificationFactory();

		System.out.println("1.SMS");
		System.out.println("2.Email");
		System.out.println("3.Push");
		System.out.println("Select your type of notification");
		notificationType = scanner.next();

		switch (notificationType) {
		case "sms":
			notification = factory.createNotification(notificationType);
			break;
		case "email":
			notification = factory.createNotification(notificationType);
			break;
		case "push":
			notification = factory.createNotification(notificationType);
			break;
		default:
			System.out.println("Invalid Notification Type");
			flag = false;
			break;
		}

		if (flag)
			notification.notifyUser();
	}
}
