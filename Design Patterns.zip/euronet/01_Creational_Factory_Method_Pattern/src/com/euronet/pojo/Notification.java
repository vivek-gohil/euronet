package com.euronet.pojo;

public interface Notification {
	public void notifyUser();
}
