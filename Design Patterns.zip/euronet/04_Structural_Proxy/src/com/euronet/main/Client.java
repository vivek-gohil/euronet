package com.euronet.main;

import com.euronet.pojo.ProxyObject;
import com.euronet.pojo.RealObject;

public class Client {
	public static void main(String[] args) {
		RealObject realObject = new ProxyObject();

		realObject.doSomething();

	}
}
