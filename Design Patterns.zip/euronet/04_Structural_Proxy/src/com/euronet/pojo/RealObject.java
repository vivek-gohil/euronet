package com.euronet.pojo;

public interface RealObject {
	public void doSomething();
}
