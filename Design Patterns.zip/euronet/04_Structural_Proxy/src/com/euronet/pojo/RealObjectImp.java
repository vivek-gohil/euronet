package com.euronet.pojo;

public class RealObjectImp implements RealObject {
	@Override
	public void doSomething() {
		System.out.println("Performing work in read object");
	}
}
