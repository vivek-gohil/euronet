package com.euronet.pojo;

public class ProxyObject extends RealObjectImp {
	@Override
	public void doSomething() {
		// Perfom additional logic and security
		// Even we can block the operation here
		System.out.println("Delegating work on real object");
		super.doSomething();
	}
}
