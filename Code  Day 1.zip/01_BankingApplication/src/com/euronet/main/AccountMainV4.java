package com.euronet.main;

import com.euronet.pojo.Savings;

public class AccountMainV4 {
	public static void main(String[] args) {
		Savings savings = new Savings(101, "Vivek Gohil", 1000, false);
	}
}
