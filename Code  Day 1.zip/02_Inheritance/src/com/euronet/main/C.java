package com.euronet.main;

import com.euronet.pojo.A;
import com.euronet.pojo.B;

public class C {
	public static void main(String[] args) {
//		B b = new B();
//		b.display();
//		System.out.println("--------------------------");
//
//		b.show();
		// A a = new A();
		B b = new B(10);
	}
}
